// METHOD#1

// setInterval(updateTime,1000); 
// function updateTime(){
//     time.innerHTML = new Date();
// }


// METHOD#2
function updateTime(){
        time.innerHTML = new Date();
}

